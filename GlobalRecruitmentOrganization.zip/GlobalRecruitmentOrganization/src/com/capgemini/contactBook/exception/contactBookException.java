package com.capgemini.contactBook.exception;

public class contactBookException extends Exception {

	private static final long serialVersionUID = 726264577455921591L;
	public contactBookException(String message) 
	{
		
		super(message);
	}
}
