package com.capgemini.contactBook.service;

import com.capgemini.contactBook.bean.EnquiryBean;
import com.capgemini.contactBook.exception.contactBookException;

public interface ContactBookService {
	public String addEnquiryDetails(EnquiryBean enquirybean) throws contactBookException;
}
