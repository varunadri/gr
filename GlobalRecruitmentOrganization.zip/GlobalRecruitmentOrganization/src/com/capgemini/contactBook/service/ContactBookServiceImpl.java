package com.capgemini.contactBook.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


import com.capgemini.contactBook.bean.*;
import com.capgemini.contactBook.dao.*;
import com.capgemini.contactBook.exception.*;
public class ContactBookServiceImpl implements ContactBookService {

contactBookDao contactbookDao;
	
	public String addEnquiryDetails(EnquiryBean enquirybean) throws contactBookException {
		
		contactbookDao= new contactDaoImpl();
		String enqry_Id_sequence;
		enqry_Id_sequence= contactbookDao.addEnquiryDetails(enquirybean);
		return enqry_Id_sequence;
	}
	
	
		public void validateEnquiry(EnquiryBean bean) throws Exception
		{
			List<String> validationErrors = new ArrayList<String>();

			//Validating name
			if(!(isValidName(bean.getFName()))) {
				validationErrors.add("\n First Name Should Be In Alphabets and minimum 3 characters long ! \n");
			}
			
			if(!(isValidName1(bean.getLName()))) {
				validationErrors.add("\n Last Name Should Be In Alphabets and minimum 3 characters long ! \n");
			/*//Validating age
			if(!(isValidAge(bean.getAge()))){
				validationErrors.add("\n Age Should Be Entered \n");
			}*/
			
			//Validating Phone Number
			if(!(isValidContactNumber(bean.getContactNumber()))){
				validationErrors.add("\n Contact Number Should be in 10 digit \n");
			}
			if(!(isValidName2(bean.getPDomain()))) {
				validationErrors.add("\n Preffered domain Should Be In Alphabets and minimum 3 characters long ! \n");
			}
			
			if(!(isValidName3(bean.getPLocation()))) {
				validationErrors.add("\n Preferred Location Should Be In Alphabets and minimum 3 characters long ! \n");}
			
			if(!validationErrors.isEmpty())
				throw new contactBookException(validationErrors +"");
		}}

		public boolean isValidName(String fname){
			Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
			Matcher nameMatcher=namePattern.matcher(fname);
			return nameMatcher.matches();
		}
		public boolean isValidName1(String lname){
			Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
			Matcher nameMatcher=namePattern.matcher(lname);
			return nameMatcher.matches();
		}
		public boolean isValidName2(String pdomain){
			Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
			Matcher nameMatcher=namePattern.matcher(pdomain);
			return nameMatcher.matches();
		}
		public boolean isValidName3(String plocation){
			Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
			Matcher nameMatcher=namePattern.matcher(plocation);
			return nameMatcher.matches();
		}
		/*public boolean isValidAge(String age){
			return (age.length()>3);
		}*/
		
		
		public boolean isValidContactNumber(String contactNumber){
			Pattern phonePattern=Pattern.compile("^[1-9]{1}[0-9]{9}$");
			Matcher phoneMatcher=phonePattern.matcher(contactNumber);
			return phoneMatcher.matches();
			
		}
		
		public boolean validateEnquirytId(String enqry_id) {
			
			Pattern idPattern = Pattern.compile("[0-9]{1,4}");
			Matcher idMatcher = idPattern.matcher(enqry_id);
			
			if(idMatcher.matches())
				return true;
			else
				return false;		
		}
}
