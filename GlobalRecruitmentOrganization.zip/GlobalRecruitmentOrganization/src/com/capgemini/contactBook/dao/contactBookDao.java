package com.capgemini.contactBook.dao;

import com.capgemini.contactBook.bean.EnquiryBean;
import com.capgemini.contactBook.exception.contactBookException;

public interface contactBookDao {
	public String addEnquiryDetails(EnquiryBean enquirybean) throws contactBookException;
}
