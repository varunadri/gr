package com.capgemini.contactBook.dao;

public interface QueryMapper {

	public static final String INSERT_QUERY="INSERT INTO Enquiry VALUES(enqry_Id_sequence.NEXTVAL,?,?,?,?,?, (select SYSDATE from DUAL))";
	public static final String ENQUIRYID_SEQUENCE="SELECT enqry_Id_sequence.CURRVAL FROM DUAL";
	
}
