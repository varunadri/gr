package com.capgemini.contactBook.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.contactBook.bean.EnquiryBean;
import com.capgemini.contactBook.exception.contactBookException;

import com.capgemini.contactBook.util.DBConnection;
public class contactDaoImpl implements contactBookDao {

Logger logger=Logger.getRootLogger();
	
	public contactDaoImpl()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	
	}
	
	@SuppressWarnings("resource")
	public String addPatientDetails(EnquiryBean patientbean) throws contactBookException 
	{
		Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		String enqry_id=null;
		
		int queryResult=0;
		try
		{	
			
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);

			
			preparedStatement.setString(1, patientbean.getFName());
			preparedStatement.setString(2, patientbean.getLName());	
			preparedStatement.setString(3, patientbean.getContactNumber());
			preparedStatement.setString(4, patientbean.getPDomain());
			preparedStatement.setString(5, patientbean.getPLocation());	
			
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QueryMapper.ENQUIRYID_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				enqry_id=resultSet.getString(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new contactBookException("Inserting Enquiry details failed ");

			}
			else
			{
				logger.info("Enquiry details added successfully:");
				return enqry_id;
			}

		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			logger.error(sqlException.getMessage());
			throw new contactBookException("Tehnical problem occured refer log");
		}

		finally
		{
			try 
			{
				//resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new contactBookException("Error in closing db connection");

			}
		}
		
		
	}

	@Override
	public String addEnquiryDetails(EnquiryBean enquirybean) throws contactBookException {
		// TODO Auto-generated method stub
		return null;
	}

	
}
