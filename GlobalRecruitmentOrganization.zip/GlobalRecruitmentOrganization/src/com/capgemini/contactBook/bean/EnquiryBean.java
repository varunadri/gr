package com.capgemini.contactBook.bean;



public class EnquiryBean {
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		
		result = prime * result + ((fName == null) ? 0 : fName.hashCode());
		result = prime * result + ((lName == null) ? 0 : lName.hashCode());
		result = prime * result + ((contactNumber == null) ? 0 : contactNumber.hashCode());
		result = prime * result + ((pDomain == null) ? 0 : pDomain.hashCode());
		result = prime * result + ((pLocation == null) ? 0 : pLocation.hashCode());
		//result = prime * result + ((regDate == null) ? 0 : regDate.hashCode());
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EnquiryBean other = (EnquiryBean)obj;
		if (fName == null) {
			if (other.fName != null)
				return false;
		} else if (!fName.equals(other.fName))
			return false;
		if (lName == null) {
			if (other.lName != null)
				return false;
		} else if (!lName.equals(other.lName))
			return false;
		if (contactNumber == null) {
			if (other.contactNumber != null)
				return false;
		} else if (!contactNumber.equals(other.contactNumber))
			return false;
		if (pDomain == null) {
			if (other.pDomain != null)
				return false;
		} else if (!pDomain.equals(other.pDomain))
			return false;
		if (pLocation == null) {
			if (other.pLocation != null)
				return false;
		} else if (!pLocation.equals(other.pLocation))
			return false;
		/*if (regDate == null) {
			if (other.regDate != null)
				return false;
		} else if (!regDate.equals(other.regDate))
			return false;*/
		return true;
	}



	private String fName;
	private String lName;
	private String contactNumber;
	private String pDomain;
	private String pLocation;
	//private Date regDate;
	
	

	public String getFName() {
		return fName;
	}

	public void setFName(String fname) {
		this.fName = fname;
	}

	public String getLName() {
		return lName;
	}

	public void setLName(String lname) {
		this.fName = lname;
	}

	



	public String getContactNumber() {
		return contactNumber;
	}



	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}



	public String getPDomain() {
		return pDomain;
	}



	public void setPDomain(String pdomain) {
		this.pDomain = pdomain;
	}

	public String getPLocation() {
		return pLocation;
	}



	public void setPLocation(String plocation) {
		this.pDomain = plocation;
	}


	/*public Date getRegDate() {
		return regDate;
	}



	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}
*/


	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Printing Enquiry Details \n");
		sb.append("fName: " +fName +"\n");
		sb.append("lName: " +lName +"\n");
		sb.append("Contact Number: "+ contactNumber +"\n");
		sb.append("pDomain: "+ pDomain +"\n");
		sb.append("pLocation: "+ pLocation +"\n");
	//sb.append("Reg Date: "+ regDate);
		return sb.toString();
	}
	

}
