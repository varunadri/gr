package com.capgemini.contactBook.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.contactBook.bean.EnquiryBean;
import com.capgemini.contactBook.exception.contactBookException;
import com.capgemini.contactBook.service.ContactBookService;
import com.capgemini.contactBook.service.ContactBookServiceImpl;

@SuppressWarnings("unused")

public class contactBookMain {

	static Scanner sc = new Scanner(System.in);
	static ContactBookService contactbookService = null;
	static ContactBookServiceImpl contactbookServiceImpl = null;
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) throws Exception {
		PropertyConfigurator.configure("resources//log4j.properties");
		EnquiryBean enquirybean = null;

		String enqry_id = null;
		int option = 0;

		while (true) {

			// show menu
			System.out.println();
			System.out.println();
			System.out.println("***********Global Recruitments**********\n");
			System.out.println("Choose an operation");
			System.out.println("1.Enter Enquiry Details ");
			System.out.println("2.View Enquiry Details on Id ");
			System.out.println("0.Exit");
			System.out.println("*************************");
			System.out.println("Please enter a Choice:");
			// accept option

			try {
				option = sc.nextInt();

				switch (option) {

				case 1:

					/*while (enquirybean  == null) {
						enquirybean   = populateEnquiryBean();
						 System.out.println(enquirybean);
					}*/

					try {
						contactbookService = new ContactBookServiceImpl();
						enqry_id = contactbookService.addEnquiryDetails(enquirybean);

						System.out.println("Enquiry details  has been successfully registered ");
						System.out.println("Enquiry  ID Is: " + enqry_id);

					} catch (contactBookException enquirysException) {
						logger.error("exception occured", enquirysException);
						System.out.println("ERROR : "
								+ enquirysException.getMessage());
					} finally {
						enqry_id = null;
						contactbookService = null;
						enquirybean = null;
					}

					break;


				case 0:

					System.out.print("Exit Enquiry Application");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1-4]");
				}// end of switch
			}

			catch (InputMismatchException e) {
				sc.nextLine();
				System.err.println("Please enter a numeric value, try again");
		}

		}// end of while
	}

	private static EnquiryBean populatePatientbean() throws Exception {

		
		EnquiryBean enquirybean = new EnquiryBean();

		System.out.println("\n Enquiry Details");

		System.out.println("Enter  First Name: ");
		enquirybean.setFName(sc.next());
		System.out.println("Enter Last Name: ");
		enquirybean.setLName(sc.next());
		System.out.println("Enter Contact Number: ");
		enquirybean.setContactNumber(sc.next());
		System.out.println("Enter Preferred Domain: ");
		enquirybean.setPDomain(sc.next());
		System.out.println("Enter Preferred Location: ");
		enquirybean.setPLocation(sc.next());
		
	
		
        contactbookServiceImpl = new ContactBookServiceImpl();
//System.out.println("After creating patient service impl object");

		try {
			contactbookServiceImpl.validateEnquiry(enquirybean);
			
			System.out.println("after validate enquiry");
			return enquirybean ;
		} catch (contactBookException patientsException) {
			logger.error("exception occured", patientsException);
			System.err.println("Invalid data:");
			System.err.println(patientsException.getMessage() + " \n Try again..");
			System.exit(0);

		}
		return null;

	}
}
