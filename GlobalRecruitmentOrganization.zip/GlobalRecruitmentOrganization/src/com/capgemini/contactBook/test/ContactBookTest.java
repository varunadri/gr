package com.capgemini.contactBook.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.contactBook.bean.EnquiryBean;
import com.capgemini.contactBook.dao.contactDaoImpl;
import com.capgemini.contactBook.exception.contactBookException;



public class ContactBookTest {

	 static contactDaoImpl dao;
	    static EnquiryBean enquirybean;

	    @BeforeClass
	    public static void initialize() {
	        dao = new contactDaoImpl();
	        enquirybean = new EnquiryBean();
	    }

	    @Test
	    public void testAddEnquiryDetails() throws contactBookException {

	        assertNotNull(dao.addEnquiryDetails(enquirybean));
	    }
	    
	    /************************************
	     * Test case for addPatientDetails()
	     * 
	     ************************************/

	    @Ignore
	    @Test
	    public void testAddEnquiryDetails1() throws contactBookException {
	        assertEquals(1001, dao.addEnquiryDetails(enquirybean));
	    }

	    /************************************
	     * Test case for addPatientDetails()
	     * 
	     ************************************/

	    @Test
	    public void testAddEnquiryDetails2() throws contactBookException {
	        
	    	enquirybean.setFName("Varun");
	    	enquirybean.setLName("K");
	    	enquirybean.setContactNumber("9000342237");
	    	enquirybean.setPDomain("Java");
	    	enquirybean.setPLocation("pune");
	        assertTrue("Data Inserted successfully",
	                Integer.parseInt(dao.addEnquiryDetails(enquirybean)) > 1);

	    }
}
